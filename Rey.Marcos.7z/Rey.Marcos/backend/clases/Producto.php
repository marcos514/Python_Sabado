<?php
include_once "AccesoDatos.php";
class Producto
{
    public $nombre;
    public $precio;

    public function __construct($nombre="",$precio="")
    {
        $this->nobre=$nombre;
        $this->precio=$precio;

    }

    public function Agregar()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into Productos (nombre,precio)values(:nombre,:precio)");
        $consulta->bindValue(':precio',$this->precio,  PDO::PARAM_STR);
        $consulta->bindValue(':nombre', $this->nombre, PDO::PARAM_STR);
        		
        return $consulta->execute();
    }

    public function Borrar()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
		delete 
		from Productos 				
		WHERE nombre=:nombre");	
        $consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_STR);
		$consulta->execute();
		return $consulta->rowCount();
    }

    public function Modificar()
	{

		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			update Productos 
			set
			precio='$this->precio',
			WHERE nombre='$this->nombre'");
		return $consulta->execute();

    }
    public static function TraerTodo()
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select from Productos");
			$consulta->execute();			
			return $consulta->fetchAll(PDO::FETCH_ASSOC);		
    }
    
    public function TraerEste()
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select  from Productos where nombre='".$this->nombre."'");
			$consulta->execute();			
			return $consulta->fetchAll(PDO::FETCH_ASSOC);
	}



}







?>