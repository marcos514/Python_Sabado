/// <reference path="node_modules/@types/jquery/index.d.ts" />
class Manejador 
{

    public static ArrayJson()
    {
        let strJson:string='[{"mail":"tomas@gmail.com","clave":"1234","nombre":"tomas","apellido":"martin","legajo":"5621","perfil":"invitado","foto":"../backend/1234.jpg"},{"mail":"marcos@gmail.com","clave":"1234","nombre":"marcos","apellido":"rey","legajo":"789","perfil":"invitado","foto":"../backend/1234.jpg"},{"mail":"tomas@gmail.com","clave":"1234","nombre":"tomas","apellido":"sanchez","legajo":"5648","perfil":"invitado","foto":"../backend/1234.jpg"},{"mail":"juan@gmail.com","clave":"1234","nombre":"juan","apellido":"siñeris","legajo":"1264","perfil":"invitado","foto":"../backend/1234.jpg"},{"mail":"mica@gmail.com","clave":"1234","nombre":"micaela","apellido":"saez","legajo":"555","perfil":"invitado","foto":"../backend/1234.jpg"}]';
        if(localStorage.getItem("arrayJson"))
        {
            console.log("Usuarios cargados con antelacion");
            console.log(localStorage.getItem("arrayJson"));
        }
        else
        {
            localStorage.setItem("arrayJson",strJson);
            console.log(strJson);
        }
        
        
    }

    public static ValidarCamposUsuario()
    {
        $("#divAlert").html(""); 
        let nombre:any=$("#nombre").val();
        let mail:any=$("#mail").val();
        let clave:any=$("#clave").val();
        let clave2:any=$("#claveComparar").val();
        let foto : any = (<HTMLInputElement>document.getElementById("foto"));
        let apellido:any=$("#apellido").val();
        let legajo:any=$("#legajo").val();

        let validadorNombre=false;
        let validadorClave=false;
        let validadorClave2=false;
        let validadorMail=false;
        let validadorApellido=false;
        let validadorLegajo=false;
        let validadorFoto=false;

        let mensaje="";
        if(nombre=="")
        {
            (<HTMLSpanElement>document.getElementById("spnNombre")).style.display="block";
            mensaje+="Ingresar nombre<br>";
            validadorNombre=true;
        }
        else if(nombre.length>10)
        {
            (<HTMLSpanElement>document.getElementById("spnNombre")).style.display="block";
            mensaje+="Nombre muy largo<br>";
            validadorNombre=true;
        }


        if(apellido=="")
        {
            (<HTMLSpanElement>document.getElementById("spnApellido")).style.display="block";
            mensaje+="Ingresar Apellido<br>";
            validadorApellido=true;
        }
        else if(apellido.length>15)
        {
            (<HTMLSpanElement>document.getElementById("spnApellido")).style.display="block";
            mensaje+="Apellido muy largo<br>";
            validadorApellido=true;
        }

        if(legajo=="")
        {
            (<HTMLSpanElement>document.getElementById("spnLegajo")).style.display="block";
            mensaje+="Ingresar Legajo<br>";
            validadorApellido=true;
        }
        else if(legajo.length>6||legajo.length<3 )
        {
            (<HTMLSpanElement>document.getElementById("spnLegajo")).style.display="block";
            mensaje+="Legajo formato erroneo<br>";
            validadorApellido=true;
        }

        if(mail=="")
        {
            (<HTMLSpanElement>document.getElementById("spnMail")).style.display="block";
            mensaje+="Ingresar Mail<br>";
            validadorMail=true;
        }
        else
        {
            let emailRegex:any = /^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i;
            //Se muestra un texto a modo de ejemplo, luego va a ser un icono
        
            if (emailRegex.test(mail)) 
            {
          
            } 
            else 
            {
                (<HTMLSpanElement>document.getElementById("spnMail")).style.display="block";
                validadorMail=true;
                mensaje+= "Formato del mail erroneo<br>"; 
            }
        }

        if(clave=="")
        {
            (<HTMLSpanElement>document.getElementById("spnClave")).style.display="block";
            mensaje+="Ingresar Clave<br>";
            validadorNombre=true;
        }
        else if(clave.length>8||clave.length<4)
        {
            (<HTMLSpanElement>document.getElementById("spnClave")).style.display="block";
            mensaje+="Clave muy largo<br>";
            validadorClave=true;
        }

        if(clave2=="")
        {
            (<HTMLSpanElement>document.getElementById("spnClaveRepetir")).style.display="block";
            mensaje+="Ingrese confirmacion de clave<br>";
            validadorNombre=true;
        }
        else if(clave2.length>8||clave2.length<4)
        {
            (<HTMLSpanElement>document.getElementById("spnClaveRepetir")).style.display="block";            
            mensaje+="Clave a confirmar formato erroneo<br>";
            validadorClave=true;
        }


        if(foto.files.length==0)
        {
            (<HTMLSpanElement>document.getElementById("spnFoto")).style.display="block";            
            mensaje+="Ingresar Foto <br>";
            validadorFoto=true;
        }
        else
        {
            let foto : any = (<HTMLInputElement>document.getElementById("foto"));
            let form:FormData=new FormData();
            if(foto.files.length==0)
            {
                alert("Error");
                return "";
            }
            form.append("foto",foto.files[0]);

            $.ajax({
                type: 'POST',
                url: "../BACKEND/",
                dataType:"json",
                data:form,
                contentType: false,
                processData: false,
            })
            .done(function (objJson) {

               if(objJson=="error")
               {
                (<HTMLSpanElement>document.getElementById("spnFoto")).style.display="block";            
                mensaje+="Extencion foto invalido <br>";
                validadorFoto=true;
               }
            })
            .fail(function(aaa){
                console.log(JSON.stringify(aaa));
                
            });
        }

        if(mensaje!="")
        {
            $("#divAlert").html('<div class="alert alert-warning" role="alert"><strong>'+mensaje+'</strong></div>');
            return true;
        }
        else
        {
            return false;
        }
        
    
    }
    public static AgregarUsuario() 
    {
        $("#divAlert").html("");
        
        if(Manejador.ValidarCamposUsuario())
        {
            return "";
        }
        
        let nombre:any=$("#nombre").val();
        let mail:any=$("#mail").val();
        let clave:any=$("#clave").val();
        let clave2:any=$("#claveComparar").val();
        let foto : any = (<HTMLInputElement>document.getElementById("foto"));
        let apellido:any=$("#apellido").val();
        let perfil:any=$("#perfil").val();
        let legajo:any=$("#legajo").val();

        if(clave==clave2)
        {
            let arrayJson:any=localStorage.getItem("arrayJson");
            let json:any=JSON.parse(arrayJson);
            let validador:boolean=false;
            for(let i=0;i<json.length;i++)
            {
                if(mail==json[i].mail )
                {
                    
                        validador=true;
                        break;              
                    
                }
            }
            if(validador)
            {
                $("#divAlert").html('<div class="alert alert-warning" role="alert"><strong>Error Mail ya ingresado</strong></div>');     
            }
            else
            {
                let usuarioNuevo=JSON.parse('{"mail":"'+mail+'","clave":"'+clave+'","nombre":"'+nombre+'","apellido":"'+apellido+'","legajo":"'+legajo+'","perfil":"'+perfil+'","foto":"'+json.length+'.jpg"}')
                json.push(usuarioNuevo);
                localStorage.setItem("arrayJson",JSON.stringify(json));
                location.href ="login.html";
            }
            
        }
        else
        {
            $("#divAlert").html('<div class="alert alert-warning" role="alert"><strong>Error la contraceña no coincide con el mail</strong></div>');
            
        }
        

         
    }

    public static validador()
    {
        $("#divAlert").html("");                        
        
        let mail:any=$("#mail").val();
        let clave:any=$("#clave").val();
        let mensaje="";
        let mailErroneo=false;
        let claveErroneo=false;
        if(mail=="")
        {
            (<HTMLSpanElement>document.getElementById("spnMail")).style.display="block";
            mensaje+="Mail vacio";
            mailErroneo=true;
        }
        if(clave=="")
        {
            (<HTMLSpanElement>document.getElementById("spnClave")).style.display="block";
            mensaje+="  -  Clave vacia";
            
            claveErroneo=true;          
        }
        if((clave.length>8 || clave.length<4) )
        {
            (<HTMLSpanElement>document.getElementById("spnClave")).style.display="block";
            mensaje+=" - Error en la cantidad de caracteres";
            claveErroneo=true;
            
        }    
        let emailRegex:any = /^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i;
            //Se muestra un texto a modo de ejemplo, luego va a ser un icono
        if(!mailErroneo)
        {
            if (emailRegex.test(mail)) 
            {
          
            } 
            else 
            {
                (<HTMLSpanElement>document.getElementById("spnMail")).style.display="block";
                mailErroneo=true;
                mensaje+= "  -Error en el formato del mail";
                
            }
        }
        
        
        if(claveErroneo!=false || mailErroneo!=false)
        {
            $("#divAlert").html('<div class="alert alert-warning" role="alert"><strong>'+mensaje+'</strong></div>');                        
            return true;
        }
        else
        {
            return true;
        }
    }

    public static VerificarUsuarioJson() 
    {
        if(!Manejador.validador())
        {
            return "";
        }
        let mail:any=$("#mail").val();
        let clave:any=$("#clave").val();

        
        let arrayJson:any=localStorage.getItem("arrayJson");
        let json:any=JSON.parse(arrayJson);
        let validador:boolean=false;
        for(let i=0;i<json.length;i++)
        {
            if(mail==json[i].mail )
            {
                if(json[i].clave==clave)
                {
                    validador=true;
                    break;              
                }
            }
        }
        if(validador)
        {

            location.href="principal.html";      
        }
        else
        {
            $("#divAlert").html('<div class="alert alert-warning" role="alert"><strong>Error la contraceña no coincide con el mail</strong></div>');
        }
        
        
    }


}